import { StrictMode } from "react";
import ReactDOM from "react-dom";
import VideoContentYT from "react-video-content-youtube";
import "./styles.css"

const rootElement = document.getElementById("root");
ReactDOM.render(
  <StrictMode>
    <div className="App">
      <h1>React video content youtube</h1>
      <h2>Demo, magic happen!</h2>
    </div>
    <VideoContentYT src="LXb3EKWsInQ" params={{ autoPlay: true }} />
  </StrictMode>,
  rootElement
);
